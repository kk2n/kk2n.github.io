#!/bin/bash


npm install