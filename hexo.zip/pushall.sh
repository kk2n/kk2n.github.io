#!/bin/bash


git add --all && git commit -m "..." && git push -u origin master