#!/bin/bash


npm install