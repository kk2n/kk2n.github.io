#!/bin/bash


hexo g