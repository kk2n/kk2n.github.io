
初始化说明
-----------------
### 1.新建目录
    建立git链接
    ```git pull origin master```

### 2.进入hexo目录
    重新安装，执行密令：
    ```npm install```

### 3.完成后，生成静态文件
    ```hexo g```
    
### 4.返回父级目录，pash all
    ```
    git add --all
    git commit -m '...'
    git push -u origin master
    ```
### 5.打开网址：http://kk2n.github.io
    

