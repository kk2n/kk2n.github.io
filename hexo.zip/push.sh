#!/bin/bash


hexo g